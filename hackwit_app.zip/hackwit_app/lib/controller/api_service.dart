import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:hackwit_app/model/data_model.dart'; 

class ApiService {
  final String baseUrl = "https://fakestoreapi.com/products";

 Future<List<Product>> fetchProducts() async {
  try {
    final response = await http.get(Uri.parse(baseUrl));

    print('Response headers: ${response.headers}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {

      if (response.headers['content-type']?.contains('application/json') ?? false) {
        List jsonResponse = json.decode(response.body);
        List<Product> products =
            jsonResponse.map((product) => Product.fromJson(product)).toList();
        return products;
      } else {

        throw Exception('Unexpected content type: ${response.headers['content-type']}');
      }
    } else {
      throw Exception('Failed to load products: ${response.statusCode}');
    }
  } catch (e) {
    print('Error occurred: $e');
    throw Exception('An error occurred while fetching products: $e');
  }
}
}
