import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hackwit_app/model/data_model.dart';

class ProductState {
  final Product product;
  final bool isFavorite;

  ProductState({
    required this.product,
    this.isFavorite = false,
  });

  ProductState copyWith({
    bool? isFavorite,
  }) {
    return ProductState(
      product: product,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }
}

class FavoriteProvider extends StateNotifier<Map<int, ProductState>> {
  FavoriteProvider() : super({});

  void toggleFavorite(Product product) {
    final productId = product.id;
    final currentProductState = state[productId];

    if (currentProductState != null) {
      final updatedProductState = currentProductState.copyWith(
        isFavorite: !currentProductState.isFavorite,
      );
      state = {
        ...state,
        productId: updatedProductState,
      };
    } else {
      final newProductState = ProductState(product: product, isFavorite: true);
      state = {
        ...state,
        productId: newProductState,
      };
    }
  }

  void removeFavorite(Product product) {
    final productId = product.id;
    state = {
      ...state..remove(productId),
    };
  }

  ProductState getProductState(Product product) {
    return state[product.id] ?? ProductState(product: product);
  }
}

final favoriteProductsProvider =
    StateNotifierProvider<FavoriteProvider, Map<int, ProductState>>((ref) {
  return FavoriteProvider();
});

