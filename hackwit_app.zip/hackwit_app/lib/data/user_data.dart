import 'package:hackwit_app/model/user_account_model.dart';

class UserStorage {
  static final List<User> _users = [];

  static void addUser(User user) {
    _users.add(user);
  }
  static User? getUser(String username, String password) {
    try {
      return _users.firstWhere(
        (user) => user.username == username && user.password == password,
      );
    } catch (e) {
      return null;
    }
  }
  
  static bool isUsernameTaken(String username) {
    return _users.any((user) => user.username == username);
  }
}
