import 'package:hackwit_app/model/data_model.dart';

class ProductState {
  final Product product;
  final bool isLiked;
  final bool isDisliked;
  final bool isFavorite; 

  ProductState({
    required this.product,
    this.isLiked = false,
    this.isDisliked = false,
    this.isFavorite = false, 
  });

  ProductState copyWith({
    Product? product,
    bool? isLiked,
    bool? isDisliked,
    bool? isFavorite,
  }) {
    return ProductState(
      product: product ?? this.product,
      isLiked: isLiked ?? this.isLiked,
      isDisliked: isDisliked ?? this.isDisliked,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }
}
