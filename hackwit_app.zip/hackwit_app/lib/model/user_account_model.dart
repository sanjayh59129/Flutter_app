class User {
  final String username;
  final String password;
  final String firstName;
  final String lastName;
  final String phoneNumber;
  final String email;

  User({
    required this.username,
    required this.password,
    required this.firstName,
    required this.lastName,
    required this.phoneNumber,
    required this.email,
  });
}
