import 'package:flutter/material.dart';
import 'package:hackwit_app/data/user_data.dart';
import 'package:hackwit_app/model/user_account_model.dart';
import 'package:hackwit_app/widgets/create_widgets/form_section.dart';
import 'package:hackwit_app/widgets/create_widgets/layout.dart';

class CreatePage extends StatefulWidget {
  final VoidCallback onBackToLogin;

  const CreatePage({super.key, required this.onBackToLogin});

  @override
  _CreatePageState createState() => _CreatePageState();
}

class _CreatePageState extends State<CreatePage> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  void _createAccount() {
    if (_formKey.currentState?.validate() ?? false) {
      final newUser = User(
        username: _usernameController.text,
        password: _passwordController.text,
        firstName: _firstNameController.text,
        lastName: _lastNameController.text,
        phoneNumber: _phoneNumberController.text,
        email: _emailController.text,
      );
      UserStorage.addUser(newUser);
      widget.onBackToLogin();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Stack(
      children: [
        Positioned.fill(
          child: Opacity(
            opacity: 0.5,
            child: Image.asset(
              "assets/icons/bgImage.avif",
              fit: BoxFit.cover,
            ),
          ),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth < 600) {
                return MobileLayout(
                  screenHeight: screenHeight,
                  screenWidth: screenWidth,
                  buildForm: () => FormSection(
                    screenHeight: screenHeight,
                    formKey: _formKey,
                    firstNameController: _firstNameController,
                    lastNameController: _lastNameController,
                    phoneNumberController: _phoneNumberController,
                    emailController: _emailController,
                    usernameController: _usernameController,
                    passwordController: _passwordController,
                    onCreateAccount: _createAccount,
                  ),
                  buildIcon: (size) => _icon(size * 0.6),
                );
              } else {
                return WebLayout(
                  screenHeight: screenHeight,
                  screenWidth: screenWidth,
                  buildForm: () => FormSection(
                    screenHeight: screenHeight,
                    formKey: _formKey,
                    firstNameController: _firstNameController,
                    lastNameController: _lastNameController,
                    phoneNumberController: _phoneNumberController,
                    emailController: _emailController,
                    usernameController: _usernameController,
                    passwordController: _passwordController,
                    onCreateAccount: _createAccount,
                  ),
                  buildIcon: (size) => _icon(size * 0.6),
                );
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _icon(double size) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white, width: 4),
        shape: BoxShape.circle,
      ),
      child: ClipOval(
        child: Image.asset(
          "assets/icons/appLogo1.jpg",
          fit: BoxFit.cover,
          width: size * 2.5,
          height: size * 2.5,
        ),
      ),
    );
  }
}
