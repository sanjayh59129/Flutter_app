import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hackwit_app/screen/home_page.dart';
import 'package:hackwit_app/widgets/product_card_widget/product_card.dart';
import 'package:hackwit_app/controller/favorite_provider.dart';

class FavoriteProductsScreen extends ConsumerWidget {
  const FavoriteProductsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favoriteProducts = ref.watch(favoriteProductsProvider);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.chevron_left,
            size: 40,
          ),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomePage()),
              (route) => false,
            );
          },
        ),
        title: const Text('Favorite Products'),
      ),
      body: favoriteProducts.isEmpty
          ? Center(
              child: Text(
                'No favorite products yet!',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            )
          : ListView.builder(
              itemCount: favoriteProducts.length,
              itemBuilder: (context, index) {
                final productState = favoriteProducts.values.toList()[index];
                return ListTile(
                  title: ProductCard(product: productState.product),
                  trailing: IconButton(
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: () {
                      ref
                          .read(favoriteProductsProvider.notifier)
                          .removeFavorite(productState.product);
                    },
                  ),
                );
              },
            ),
    );
  }
}
