
import 'package:flutter/material.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/screen/profile_slidebar.dart';
import 'package:hackwit_app/widgets/bottom_nav_widget/bottom_nav_bar.dart';
import 'package:hackwit_app/widgets/home_page_widget/product_search_bar.dart';
import 'package:hackwit_app/widgets/home_page_widget/home_list_view.dart';
import 'package:hackwit_app/widgets/home_page_widget/bottom_navigation_handler.dart';
import 'package:hackwit_app/widgets/home_page_widget/product_search_functionality.dart';
import 'package:hackwit_app/widgets/home_page_widget/home_page_top_bar.dart';
import 'package:hackwit_app/controller/api_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late final AnimationController _sidebarAnimationController;
  late final Animation<Offset> _sidebarAnimation;
  late Future<List<Product>> _productsFuture;
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  int _selectedIndex = 0;
  final ApiService _apiService = ApiService(); 

  @override
  void initState() {
    super.initState();
    _sidebarAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _sidebarAnimation = Tween<Offset>(
      begin: const Offset(-1, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _sidebarAnimationController,
      curve: Curves.easeInOut,
    ));
    _productsFuture = fetchProducts(); // Initialize products future
  }

  Future<List<Product>> fetchProducts() async {
    try {
      List<Product> products = await _apiService.fetchProducts(); // Fetch products using ApiService
      setState(() {
        _products = products;
        _filteredProducts = products;
      });
      return products;
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load products: $error')),
      );
      rethrow;
    }
  }

  @override
  void dispose() {
    _sidebarAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final mediaQuery = MediaQuery.of(context);
    final screenWidth = mediaQuery.size.width;
    final screenHeight = mediaQuery.size.height;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Stack(
        children: [
          SafeArea(
            child: Padding(
              padding: EdgeInsets.all(screenWidth * 0.05),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  HomePageTopBar(
                    sidebarAnimationController: _sidebarAnimationController,
                    screenWidth: screenWidth,
                    screenHeight: screenHeight,
                    theme: theme,
                  ),
                  SizedBox(height: screenHeight * 0.03),
                  ProductSearchBar(
                    onSearch: (query) =>
                        ProductSearchFunctionality.updateSearchQuery(
                      query,
                      _products,
                      _filteredProducts,
                      setState,
                    ),
                    screenWidth: screenWidth,
                  ),
                  SizedBox(height: screenHeight * 0.02),
                  ProductListView(
                    productsFuture: _productsFuture,
                    filteredProducts: _filteredProducts,
                  ),
                ],
              ),
            ),
          ),
          SlideTransition(
            position: _sidebarAnimation,
            child: const ProfileSidebar(
              profileImage: "https://freesvg.org/img/winkboy.png",
              name: "Sanjay H",
              username: "sanjayh",
              email: "er.sanjayh@gmail.com",
              phoneNumber: "+9363645319",
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavBar(
        selectedIndex: _selectedIndex,
        onItemTapped: (index) {
          setState(() {
            _selectedIndex = index;
          });
          BottomNavigationHandler.onItemTapped(index,_selectedIndex,_products,_filteredProducts,_sidebarAnimationController,setState,context );
        },
        products: _products,
        onCloseSidebar: () {
          if (_sidebarAnimationController.isCompleted) {
            _sidebarAnimationController.reverse();
          }
        },
      ),
    );
  }
}
