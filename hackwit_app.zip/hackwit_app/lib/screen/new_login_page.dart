import 'package:flutter/material.dart';
import 'package:hackwit_app/widgets/login_widgets/login_icon.dart';
import 'package:hackwit_app/widgets/login_widgets/input_field.dart';
import 'package:hackwit_app/widgets/login_widgets/login_button.dart';
import 'package:hackwit_app/widgets/login_widgets/create_button.dart';
import 'package:hackwit_app/widgets/login_widgets/extra_text.dart';

class NewLoginPage extends StatefulWidget {
  final VoidCallback onSignIn;
  final VoidCallback onCreateAccount;

  const NewLoginPage({
    super.key,
    required this.onSignIn,
    required this.onCreateAccount,
  });

  @override
  _NewLoginPageState createState() => _NewLoginPageState();
}

class _NewLoginPageState extends State<NewLoginPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Color usernameTextColor = Colors.white;
  Color passwordTextColor = Colors.white;

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final theme = Theme.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        bool isDesktop = constraints.maxWidth > 600;

        return Stack(
          children: [
            Positioned.fill(
              child: Opacity(
                opacity: 0.5,
                child: Image.asset(
                  "assets/icons/bgImage.avif",
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Scaffold(
              backgroundColor: Colors.transparent,
              body: Center(
                child: SingleChildScrollView(
                  padding: EdgeInsets.symmetric(
                    vertical: screenHeight * 0.1,
                    horizontal: isDesktop ? screenWidth * 0.2 : 20,
                  ),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(
                      maxWidth: 400,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        LoginIcon(screenWidth: screenWidth, isDesktop: isDesktop),
                        SizedBox(height: screenHeight * 0.05),
                        InputField(
                          hintText: "Username",
                          controller: usernameController,
                          textColor: usernameTextColor,
                        ),
                        SizedBox(height: screenHeight * 0.03),
                        InputField(
                          hintText: "Password",
                          isPassword: true,
                          controller: passwordController,
                          textColor: passwordTextColor,
                        ),
                        SizedBox(height: screenHeight * 0.04),
                        LoginButton(
                          usernameController: usernameController,
                          passwordController: passwordController,
                          onSignIn: widget.onSignIn,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          "Forgot Password?",
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                        SizedBox(height: screenHeight * 0.07),
                        const ExtraText(),
                        const SizedBox(height: 8),
                        CreateButton(
                          screenWidth: screenWidth,
                          theme: theme,
                          onCreateAccount: widget.onCreateAccount,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
