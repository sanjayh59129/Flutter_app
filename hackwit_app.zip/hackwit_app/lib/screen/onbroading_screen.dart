import 'package:flutter/material.dart';
import 'package:hackwit_app/screen/home_page.dart';
import 'package:hackwit_app/screen/new_login_page.dart';
import 'package:hackwit_app/screen/create_page.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}
class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  bool onLastPage = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            controller: _controller,
            itemCount: 2,
            onPageChanged: (index) {
              setState(() {
                onLastPage = (index == 1);
              });
            },
            itemBuilder: (context, index) {
              return AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  double value = 1.0;
                  if (_controller.position.haveDimensions) {
                    value = _controller.page! - index;
                    value = (1 - (value.abs() * 0.3)).clamp(0.0, 1.0);
                  }
                  return Transform(
                    transform: Matrix4.identity()
                      ..scale(value, value)
                      ..rotateZ((1 - value) * 0.5),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(30),
                      child: child,
                    ),
                  );
                },
                child: _buildPage(context, index),
              );
            },
          ),
        ],
      ),
    );
  }
  Widget _buildPage(BuildContext context, int index) {
    switch (index) {
      case 0:
        return NewLoginPage(
          onSignIn: () {
            Navigator.of(context).pushReplacement(
              _createRoute(const HomePage()),
            );
          },
          onCreateAccount: () {
            _controller.nextPage(
              duration: const Duration(milliseconds: 500),
              curve: Curves.easeIn,
            );
          },
        );
      case 1:
        return CreatePage(
          onBackToLogin: () {
            _controller.previousPage(
              duration: const Duration(milliseconds: 500),
              curve: Curves.easeIn,
            );
          },
        );
      default:
        return Container();
    }
  }
  Route _createRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const curve = Curves.easeInOut;
        var fadeTween = Tween<double>(begin: 0.0, end: 1.0)
            .chain(CurveTween(curve: curve));
        var scaleTween = Tween<double>(begin: 0.95, end: 1.0)
            .chain(CurveTween(curve: curve));
        var slideTween = Tween<Offset>(begin: const Offset(0.0, 0.1), end: Offset.zero)
            .chain(CurveTween(curve: curve));
        var fadeAnimation = animation.drive(fadeTween);
        var scaleAnimation = animation.drive(scaleTween);
        var slideAnimation = animation.drive(slideTween);
        return FadeTransition(
          opacity: fadeAnimation,
          child: SlideTransition(
            position: slideAnimation,
            child: ScaleTransition(
              scale: scaleAnimation,
              child: child,
            ),
          ),
        );
      },
    );
  }
}