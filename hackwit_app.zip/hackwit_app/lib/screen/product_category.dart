import 'package:flutter/material.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/screen/home_page.dart';
import 'package:hackwit_app/widgets/category_products_screen.dart';

class ProductCategoryScreen extends StatelessWidget {
  final List<Product> products;
  const ProductCategoryScreen({
    super.key,
    required this.products,
  });

  @override
  Widget build(BuildContext context) {
    final categories =
        products.map((product) => product.category).toSet().toList();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.chevron_left,
            size: 40,
          ),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomePage()),
              (route) => false,
            );
          },
        ),
        title: const Text('Categories'),
      ),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          final color = const Color.fromARGB(255, 143, 76, 76);

          return ListTile(
            title: Text(
              category,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: color,
                    fontSize: 22,
                  ),
            ),
            contentPadding:
                const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CategoryProductsScreen(
                    products: products,
                    category: category,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
