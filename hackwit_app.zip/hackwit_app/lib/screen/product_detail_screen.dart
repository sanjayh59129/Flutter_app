import 'package:flutter/material.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/widgets/product_details_screen_widget/product_action_button.dart';
import 'package:hackwit_app/widgets/product_details_screen_widget/product_image.section.dart';
import 'package:hackwit_app/widgets/product_details_screen_widget/product_info_section.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({super.key, required this.product});

  @override
  _ProductDetailScreenState createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  bool isLiked = false;
  bool isDisliked = false;

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.chevron_left,
            size: 40,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(widget.product.title),
        backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(screenWidth * 0.04),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ProductImageSection(
                product: widget.product,
                isLiked: isLiked,
                isDisliked: isDisliked,
                onLikePressed: () {
                  setState(() {
                    isLiked = !isLiked;
                    if (isLiked) {
                      isDisliked = false;
                    }
                  });
                },
                onDislikePressed: () {
                  setState(() {
                    isDisliked = !isDisliked;
                    if (isDisliked) {
                      isLiked = false;
                    }
                  });
                },
              ),
              ProductInfoSection(product: widget.product),
              ProductActionButton(
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}
