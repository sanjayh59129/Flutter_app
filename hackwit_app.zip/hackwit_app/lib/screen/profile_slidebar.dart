import 'package:flutter/material.dart';
import 'package:hackwit_app/widgets/profile_button.dart';

class ProfileSidebar extends StatelessWidget {
  final String profileImage;
  final String name;
  final String username;
  final String email;
  final String phoneNumber;

  const ProfileSidebar({super.key,required this.profileImage,required this.name,required this.username,required this.email,required this.phoneNumber,});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final theme = Theme.of(context);
    final primaryColor = theme.colorScheme.primary;

    return Drawer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(
              name,
              style: TextStyle(
                fontSize: screenWidth * 0.045,
                fontWeight: FontWeight.bold,
              ),
            ),
            accountEmail: Text(
              email,
              style: TextStyle(
                fontSize: screenWidth * 0.04,
              ),
            ),
            currentAccountPicture: CircleAvatar(
              backgroundImage: NetworkImage(profileImage),
              radius: screenWidth * 0.1,
            ),
            decoration: BoxDecoration(
              color: primaryColor,
            ),
          ),
          ListTile(
            leading: Icon(Icons.person, color: primaryColor),
            title: Text(
              username,
              style: TextStyle(fontSize: screenWidth * 0.04),
            ),
            onTap: () {
            },
          ),
          ListTile(
            leading: Icon(Icons.email, color: primaryColor),
            title: Text(
              email,
              style: TextStyle(fontSize: screenWidth * 0.04),
            ),
            onTap: () {
            },
          ),
          ListTile(
            leading: Icon(Icons.phone, color: primaryColor),
            title: Text(
              phoneNumber,
              style: TextStyle(fontSize: screenWidth * 0.04),
            ),
            onTap: () {},
          ),
          const Spacer(),
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: screenWidth * 0.04,
              vertical: screenHeight * 0.02,
            ),
            child: LogoutButton(
              screenWidth: screenWidth,
              screenHeight: screenHeight,
            ),
          ),
        ],
      ),
    );
  }
}
