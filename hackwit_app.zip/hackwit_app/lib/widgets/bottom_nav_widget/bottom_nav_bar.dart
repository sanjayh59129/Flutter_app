import 'package:flutter/material.dart';
import 'package:hackwit_app/screen/favorite_product.dart';
import 'package:hackwit_app/screen/product_category.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/widgets/bottom_nav_widget/custom_bottom_navigation.dart';

class BottomNavBar extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onItemTapped;
  final List<Product> products;
  final VoidCallback onCloseSidebar;

  const BottomNavBar({
    super.key,
    required this.selectedIndex,
    required this.onItemTapped,
    required this.products,
    required this.onCloseSidebar,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final theme = Theme.of(context);

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
      child: BottomNavigationBar(
        items: [
          CustomBottomNavigationBarItem.build(
            icon: Icons.home_filled,
            isSelected: selectedIndex == 0,
            screenWidth: screenWidth,
            theme: theme,
          ),
          CustomBottomNavigationBarItem.build(
            icon: Icons.grid_view_rounded,
            isSelected: selectedIndex == 1,
            screenWidth: screenWidth,
            theme: theme,
          ),
          CustomBottomNavigationBarItem.build(
            icon: Icons.favorite,
            isSelected: selectedIndex == 2,
            screenWidth: screenWidth,
            theme: theme,
          ),
          CustomBottomNavigationBarItem.build(
            icon: Icons.person,
            isSelected: selectedIndex == 3,
            screenWidth: screenWidth,
            theme: theme,
          ),
        ],
        currentIndex: selectedIndex,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        onTap: (index) {
          if (index == selectedIndex) {
            // If the same index is clicked, handle accordingly
            if (index == 0) {
              // If Home is clicked again, pop until home is at the top
              Navigator.popUntil(context, (route) => route.isFirst);
            }
            return; // Prevent further action if the same item is clicked
          }

          // Always close the sidebar when a new item is tapped
          onCloseSidebar();

          // Handle navigation based on the index
          switch (index) {
            case 0:
              // Return to home and reset selected index
              Navigator.popUntil(context, (route) => route.isFirst);
              onItemTapped(index);
              break;
            case 1:
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProductCategoryScreen(
                    products: products,
                  ),
                ),
              ).then((_) {
                // Reset the selected index when returning
                onItemTapped(selectedIndex);
              });
              break;
            case 2:
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const FavoriteProductsScreen(),
                ),
              ).then((_) {
                // Reset the selected index when returning
                onItemTapped(selectedIndex);
              });
              break;
            case 3:
              // Handle profile page navigation
              onItemTapped(index);
              break;
            default:
              onItemTapped(index);
          }
        },
        backgroundColor: theme.colorScheme.background,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
    );
  }
}
