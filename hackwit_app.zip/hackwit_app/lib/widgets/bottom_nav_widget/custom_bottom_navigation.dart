import 'package:flutter/material.dart';

class CustomBottomNavigationBarItem {
  static BottomNavigationBarItem build({
    required IconData icon,
    required bool isSelected,
    required double screenWidth,
    required ThemeData theme,
  }) {
    return BottomNavigationBarItem(
      icon: Container(
        padding: EdgeInsets.all(screenWidth * 0.02),
        decoration: BoxDecoration(
          color: isSelected
              ? theme.colorScheme.primary.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Icon(
          icon,
          color: isSelected
              ? theme.colorScheme.primary
              : theme.colorScheme.onBackground,
          size: screenWidth * 0.075,
        ),
      ),
      label: '',
    );
  }
}
