import 'package:flutter/material.dart';
import 'input_field.dart';

class FormSection extends StatelessWidget {
  final double screenHeight;
  final GlobalKey<FormState> formKey;
  final TextEditingController firstNameController;
  final TextEditingController lastNameController;
  final TextEditingController phoneNumberController;
  final TextEditingController emailController;
  final TextEditingController usernameController;
  final TextEditingController passwordController;
  final VoidCallback onCreateAccount;

  const FormSection({
    super.key,
    required this.screenHeight,
    required this.formKey,
    required this.firstNameController,
    required this.lastNameController,
    required this.phoneNumberController,
    required this.emailController,
    required this.usernameController,
    required this.passwordController,
    required this.onCreateAccount,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          InputField(
            hintText: "First Name",
            controller: firstNameController,
          ),
          SizedBox(height: screenHeight * 0.01),
          InputField(
            hintText: "Last Name",
            controller: lastNameController,
          ),
          SizedBox(height: screenHeight * 0.01),
          InputField(
            hintText: "Phone Number",
            controller: phoneNumberController,
          ),
          SizedBox(height: screenHeight * 0.01),
          InputField(
            hintText: "Email ID",
            controller: emailController,
            validator: (value) {
              if (value == null ||
                  value.isEmpty ||
                  !RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                return 'Please enter a valid email address';
              }
              return null;
            },
          ),
          SizedBox(height: screenHeight * 0.01),
          InputField(
            hintText: "Username",
            controller: usernameController,
            textColor: Colors.white,
          ),
          SizedBox(height: screenHeight * 0.01),
          InputField(
            hintText: "Password",
            controller: passwordController,
            isPassword: true,
            validator: (value) {
              if (value == null || value.isEmpty || value.length < 6) {
                return 'Password must be at least 6 characters';
              }
              return null;
            },
          ),
          SizedBox(height: screenHeight * 0.04),
          ElevatedButton(
            onPressed: onCreateAccount,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(
                vertical: 16.0,
                horizontal: 32.0,
              ),
              textStyle: const TextStyle(
                fontSize: 20,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(32),
              ),
            ),
            child: const Text("Create Account"),
          ),
        ],
      ),
    );
  }
}
