import 'package:flutter/material.dart';
import 'package:hackwit_app/widgets/create_widgets/form_section.dart';

class MobileLayout extends StatelessWidget {
  final double screenHeight;
  final double screenWidth;
  final FormSection Function() buildForm;
  final Widget Function(double) buildIcon;

  const MobileLayout({
    super.key,
    required this.screenHeight,
    required this.screenWidth,
    required this.buildForm,
    required this.buildIcon,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            buildIcon(screenWidth * 0.3),
            SizedBox(height: screenHeight * 0.02),
            buildForm(),
          ],
        ),
      ),
    );
  }
}

class WebLayout extends StatelessWidget {
  final double screenHeight;
  final double screenWidth;
  final FormSection Function() buildForm;
  final Widget Function(double) buildIcon;

  const WebLayout({
    Key? key,
    required this.screenHeight,
    required this.screenWidth,
    required this.buildForm,
    required this.buildIcon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(width: screenWidth * 0.1),
          Expanded(child: buildForm()),
          SizedBox(width: screenWidth * 0.1),
          buildIcon(screenWidth * 0.3),
        ],
      ),
    );
  }
}
