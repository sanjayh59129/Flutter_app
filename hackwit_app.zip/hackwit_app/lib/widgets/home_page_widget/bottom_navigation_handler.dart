import 'package:flutter/material.dart';
import 'package:hackwit_app/model/data_model.dart';

class BottomNavigationHandler {
  static void onItemTapped(
    int index,
    int selectedIndex,
    List<Product> products,
    List<Product> filteredProducts,
    AnimationController sidebarAnimationController,
    void Function(VoidCallback fn) setState,
    BuildContext context,
  ) {
    setState(() {
      selectedIndex = index;

      if (index == 0) {

        Navigator.of(context).popUntil((route) => route.isFirst);
        filteredProducts = products; 
      } else if (index == 1) {
        filteredProducts = products
            .where((product) => product.category == "electronics")
            .toList();
      } else if (index == 2) {
        filteredProducts = products
            .where((product) => product.category == "jewelery")
            .toList();
      }

      if (index == 3) {
        if (sidebarAnimationController.isDismissed) {
          sidebarAnimationController.forward();
        } else {
          sidebarAnimationController.reverse();
        }
      }
    });
    if (index != 3 && sidebarAnimationController.isCompleted) {
      sidebarAnimationController.reverse();
    }
  }
}
