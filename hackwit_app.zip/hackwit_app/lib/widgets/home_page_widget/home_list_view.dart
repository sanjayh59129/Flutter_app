import 'package:flutter/material.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/widgets/product_card_widget/product_card.dart';

class ProductListView extends StatelessWidget {
  final Future<List<Product>> productsFuture;
  final List<Product> filteredProducts;

  const ProductListView({
    super.key,
    required this.productsFuture,
    required this.filteredProducts,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: FutureBuilder<List<Product>>(
        future: productsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No products available'));
          } else {
            return ListView.builder(
              itemCount: filteredProducts.length,
              itemBuilder: (context, index) {
                return ProductCard(product: filteredProducts[index]);
              },
            );
          }
        },
      ),
    );
  }
}
