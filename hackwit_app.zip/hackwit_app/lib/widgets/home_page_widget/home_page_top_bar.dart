import 'package:flutter/material.dart';

class HomePageTopBar extends StatelessWidget {
  final AnimationController sidebarAnimationController;
  final double screenWidth;
  final double screenHeight;
  final ThemeData theme;

  const HomePageTopBar({
    super.key,
    required this.sidebarAnimationController,
    required this.screenWidth,
    required this.screenHeight,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: () {
                sidebarAnimationController.isCompleted
                    ? sidebarAnimationController.reverse()
                    : sidebarAnimationController.forward();
              },
              child: Container(
                width: screenWidth * 0.12,
                height: screenWidth * 0.12,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(screenWidth * 0.08),
                  image: const DecorationImage(
                    image: NetworkImage("https://freesvg.org/img/winkboy.png"),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            SizedBox(width: screenWidth * 0.03),
            Text(
              "Hi, Sanjay",
              style: theme.textTheme.bodyLarge?.copyWith(
                  color: theme.colorScheme.onBackground,
                  fontSize: screenHeight * 0.023),
            ),
            const Spacer(),
            IconButton(
              icon: Icon(
                Icons.menu_outlined,
                size: screenWidth * 0.08,
                color: theme.iconTheme.color,
              ),
              onPressed: () {},
            ),
          ],
        ),
      ],
    );
  }
}
