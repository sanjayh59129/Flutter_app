import 'package:flutter/material.dart';

class ProductSearchBar extends StatelessWidget {
  final Function(String) onSearch;
  final double screenWidth;

  const ProductSearchBar({
    super.key,
    required this.onSearch,
    required this.screenWidth,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(screenWidth * 0.08),
        border: Border.all(
          color: theme.dividerColor,
          width: screenWidth * 0.003,
        ),
      ),
      padding: EdgeInsets.all(screenWidth * 0.03),
      child: Row(
        children: [
          Icon(
            Icons.search,
            color: theme.iconTheme.color?.withOpacity(0.6),
            size: screenWidth * 0.08,
          ),
          SizedBox(width: screenWidth * 0.03),
          Expanded(
            child: TextField(
              onChanged: onSearch,
              decoration: InputDecoration(
                hintText: 'Search',
                border: InputBorder.none,
                hintStyle: theme.textTheme.bodyLarge?.copyWith(
                  color: theme.hintColor,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
