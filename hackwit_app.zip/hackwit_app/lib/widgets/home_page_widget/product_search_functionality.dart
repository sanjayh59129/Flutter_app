import 'package:flutter/material.dart';
import 'package:hackwit_app/model/data_model.dart';

class ProductSearchFunctionality {
  static void updateSearchQuery(
    String query,
    List<Product> products,
    List<Product> filteredProducts,
    void Function(VoidCallback fn) setState,
  ) {
    setState(() {
      filteredProducts = products.where((product) {
        final productName = product.title.toLowerCase();
        final queryLower = query.toLowerCase();
        return productName.contains(queryLower);
      }).toList();
    });
  }
}
