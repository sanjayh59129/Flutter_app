import 'package:flutter/material.dart';

class CreateButton extends StatelessWidget {
  final double screenWidth;
  final ThemeData theme;
  final VoidCallback onCreateAccount;

  const CreateButton({
    super.key,
    required this.screenWidth,
    required this.theme,
    required this.onCreateAccount,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: screenWidth * 0.5,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(vertical: 16),
          backgroundColor: Colors.white,
          foregroundColor: theme.primaryColor,
        ),
        onPressed: onCreateAccount,
        child: const Text(
          "Create",
          style: TextStyle(fontSize: 20, color: Colors.blue),
        ),
      ),
    );
  }
}
