import 'package:flutter/material.dart';

class ExtraText extends StatelessWidget {
  const ExtraText({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Text(
          "Don't have an account?",
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
      ],
    );
  }
}
