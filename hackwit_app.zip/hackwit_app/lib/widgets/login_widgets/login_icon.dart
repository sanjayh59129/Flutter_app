import 'package:flutter/material.dart';

class LoginIcon extends StatelessWidget {
  final double screenWidth;
  final bool isDesktop;

  const LoginIcon({
    super.key,
    required this.screenWidth,
    required this.isDesktop,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white, width: 4),
        shape: BoxShape.circle,
      ),
      child: ClipOval(
        child: Image.asset(
          "assets/icons/appLogo1.jpg",
          fit: BoxFit.cover,
          width: screenWidth * (isDesktop ? 0.2 : 0.4),
          height: screenWidth * (isDesktop ? 0.2 : 0.4),
        ),
      ),
    );
  }
}
