import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/controller/favorite_provider.dart';

class FavoriteButton extends ConsumerWidget {
  final Product product;

  const FavoriteButton({super.key, required this.product});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final screenWidth = MediaQuery.of(context).size.width;
    final productState = ref.watch(favoriteProductsProvider.select(
      (state) => state[product.id] ?? ProductState(product: product),
    ));

    return IconButton(
      icon: Icon(
        productState.isFavorite ? Icons.favorite : Icons.favorite_border,
        color: productState.isFavorite
            ? theme.colorScheme.primary
            : theme.colorScheme.onSurface.withOpacity(0.6),
        size: screenWidth * 0.07,
      ),
      onPressed: () {
        ref.read(favoriteProductsProvider.notifier).toggleFavorite(product);
      },
    );
  }
}
