import 'package:flutter/material.dart';

class LikeDislikeButtons extends StatelessWidget {
  final bool isLiked;
  final bool isDisliked;
  final VoidCallback onLiked;
  final VoidCallback onDisliked;

  const LikeDislikeButtons({
    super.key,
    required this.isLiked,
    required this.isDisliked,
    required this.onLiked,
    required this.onDisliked,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final screenWidth = MediaQuery.of(context).size.width;

    return Row(
      children: [
        _buildIconButton(
          icon: Icons.thumb_up_off_alt_rounded,
          color: isLiked
              ? theme.colorScheme.primary
              : theme.colorScheme.onSurface.withOpacity(0.6),
          onPressed: onLiked,
          size: screenWidth * 0.07,
        ),
        SizedBox(width: screenWidth * 0.02),
        _buildIconButton(
          icon: Icons.thumb_down_alt_rounded,
          color: isDisliked
              ? theme.colorScheme.primary
              : theme.colorScheme.onSurface.withOpacity(0.6),
          onPressed: onDisliked,
          size: screenWidth * 0.07,
        ),
      ],
    );
  }

  Widget _buildIconButton({
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
    required double size,
  }) {
    return IconButton(
      icon: Icon(icon, color: color, size: size),
      onPressed: onPressed,
    );
  }
}
