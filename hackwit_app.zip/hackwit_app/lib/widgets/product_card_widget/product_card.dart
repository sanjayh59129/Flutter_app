import 'package:flutter/material.dart';
import 'package:hackwit_app/widgets/product_card_widget/favorite_button.dart';
import 'package:hackwit_app/widgets/product_card_widget/like_dislike_button.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/screen/product_detail_screen.dart';

class ProductCard extends StatefulWidget {
  final Product product;

  const ProductCard({super.key, required this.product});

  @override
  _ProductCardState createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  bool _isLiked = false;
  bool _isDisliked = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailScreen(product: widget.product),
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.symmetric(
          vertical: screenHeight * 0.01,
          horizontal: screenWidth * 0.04,
        ),
        decoration: BoxDecoration(
          color: theme.cardColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: theme.shadowColor.withOpacity(0.2),
              spreadRadius: 0,
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(16)),
              child: Container(
                color: Colors.white, // White background for image container
                child: AspectRatio(
                  aspectRatio: 16 / 9,
                  child: Image.network(
                    widget.product.image,
                    fit: BoxFit.contain, // Adjust image fit to 'contain'
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(screenWidth * 0.04),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.product.title,
                    style: theme.textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.primary,
                        ) ??
                        TextStyle(
                          fontSize: screenWidth * 0.05,
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.primary,
                        ),
                  ),
                  SizedBox(height: screenHeight * 0.01),
                  Text(
                    widget.product.description.length > 80
                        ? '${widget.product.description.substring(0, 80)}...'
                        : widget.product.description,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodyMedium?.copyWith(
                          color:
                              theme.colorScheme.onBackground.withOpacity(0.9),
                        ) ??
                        TextStyle(
                          fontSize: screenWidth * 0.035,
                          color:
                              theme.colorScheme.onBackground.withOpacity(0.7),
                        ),
                  ),
                  SizedBox(height: screenHeight * 0.01),
                  Row(
                    children: [
                      LikeDislikeButtons(
                        isLiked: _isLiked,
                        isDisliked: _isDisliked,
                        onLiked: () {
                          setState(() {
                            _isLiked = !_isLiked;
                            if (_isLiked) _isDisliked = false;
                          });
                        },
                        onDisliked: () {
                          setState(() {
                            _isDisliked = !_isDisliked;
                            if (_isDisliked) _isLiked = false;
                          });
                        },
                      ),
                      const Spacer(),
                      FavoriteButton(product: widget.product),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
