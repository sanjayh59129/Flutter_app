import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/controller/favorite_provider.dart';

class ProductImageSection extends ConsumerWidget {
  final Product product;
  final bool isLiked;
  final bool isDisliked;
  final VoidCallback onLikePressed;
  final VoidCallback onDislikePressed;

  const ProductImageSection({
    super.key,
    required this.product,
    required this.isLiked,
    required this.isDisliked,
    required this.onLikePressed,
    required this.onDislikePressed,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    final productState = ref.watch(favoriteProductsProvider.select(
      (state) => state[product.id] ?? ProductState(product: product),
    ));

    return Stack(
      children: [
        Container(
          height: screenHeight * 0.35,
          width: double.infinity,
          color: Colors.white,
          child: Image.network(
            product.image,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: screenHeight * 0.01,
          right: screenWidth * 0.02,
          child: Container(
            padding: EdgeInsets.all(screenWidth * 0.015),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: const Row(
              children: [
                Icon(
                  Icons.star,
                  color: Colors.yellow,
                  size: 16,
                ),
                SizedBox(width: 4),
                Text(
                  '4.5',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(width: 8),
                Text(
                  '(120)',
                  style: TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
        Positioned(
          top: screenHeight * 0.3,
          right: screenWidth * 0.02,
          child: Column(
            children: [
              IconButton(
                icon: Icon(
                  Icons.thumb_up,
                  color: isLiked
                      ? const Color.fromARGB(255, 3, 69, 122)
                      : Colors.grey,
                  size: 32,
                ),
                onPressed: onLikePressed,
              ),
              const SizedBox(height: 8),
              IconButton(
                icon: Icon(
                  Icons.thumb_down,
                  color: isDisliked
                      ? const Color.fromARGB(255, 3, 41, 110)
                      : Colors.grey,
                  size: 32,
                ),
                onPressed: onDislikePressed,
              ),
            ],
          ),
        ),
        Positioned(
          top: screenHeight * 0.01,
          left: screenWidth * 0.02,
          child: IconButton(
            icon: Icon(
              Icons.favorite,
              color: productState.isFavorite
                  ? const Color.fromARGB(255, 58, 97, 109)
                  : Colors.grey,
              size: 32,
            ),
            onPressed: () {
              ref
                  .read(favoriteProductsProvider.notifier)
                  .toggleFavorite(product);
            },
          ),
        ),
      ],
    );
  }
}
