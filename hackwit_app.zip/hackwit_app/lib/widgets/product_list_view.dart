import 'package:flutter/material.dart';
import 'package:hackwit_app/model/data_model.dart';
import 'package:hackwit_app/widgets/product_card_widget/product_card.dart';

class ProductListView extends StatelessWidget {
  final List<Product> products;
  final String searchQuery;

  const ProductListView({
    super.key,
    required this.products,
    required this.searchQuery,
  });

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final theme = Theme.of(context);
    final filteredProducts = products.where((product) {
      return product.title.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();
    return Stack(
      children: [
        ListView.builder(
          padding: EdgeInsets.only(
            bottom: screenHeight * 0.1,
            left: screenWidth * 0.02,
            right: screenWidth * 0.02,
          ),
          itemCount: filteredProducts.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: EdgeInsets.symmetric(
                vertical: screenHeight * 0.02,
              ),
              child: ProductCard(product: filteredProducts[index]),
            );
          },
        ),
        if (searchQuery.isEmpty)
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: screenHeight * 0.1,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    theme.colorScheme.background.withOpacity(0.0),
                    theme.colorScheme.background.withOpacity(0.5),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
